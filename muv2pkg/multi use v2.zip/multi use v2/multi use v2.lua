ExperienceIsRunning = true
while true do
	function changeMaterial()
		workspace.Part.Material = Enum.Material.Air
		task.wait(4)
		workspace.Part.Material = Enum.Materail.Pebble
		task.wait(5)
		
	end
	
	changeMaterial()
	
	
end
ExperienceIsRunning = true
while true do
	function changeColor()
		local part = workspace:FindFirstChild("part")
		part.BrickColor = BrickColor.new("Artichoke")
		task.wait(5)
		part.BrickColor = BrickColor.new("Beige")
		task.wait(5)
	end
	
	changeColor()
end
ExperienceIsRunning = true
while true do
	function changeTransparency()
		workspace.Part.Trasparency = 0.6
		task.wait(7)
		workspace.Part.Transparency = 0.3
	end
	
	changeTransparency()
end
ExperienceIsRunning = true
while true do
	function changeMaterialAndColor()
		local part = workspace:FindFirstChild("part")
		workspace.Part.Material = Enum.Material.Brick
		task.wait(8)
		part.BrickColor = BrickColor.new("Really red")
		task.wait(6)
		workspace.Part.Material = Enum.Material.Air
		task.wait(3)
	end
	
	changeMaterialAndColor()
end
